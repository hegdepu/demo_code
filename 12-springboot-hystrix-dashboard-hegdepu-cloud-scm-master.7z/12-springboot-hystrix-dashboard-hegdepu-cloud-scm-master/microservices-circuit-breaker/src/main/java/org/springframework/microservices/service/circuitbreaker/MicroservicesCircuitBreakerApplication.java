package org.springframework.microservices.service.circuitbreaker;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.circuitbreaker.EnableCircuitBreaker;
import org.springframework.cloud.netflix.hystrix.EnableHystrix;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
//@EnableHystrix
@EnableCircuitBreaker
@SpringBootApplication
public class MicroservicesCircuitBreakerApplication {

	
	//http://localhost:7073/boom
	//http://localhost:7073/actuator/hystrix.stream
	
	
	public static void main(String[] args) {
		SpringApplication.run(MicroservicesCircuitBreakerApplication.class, args);
	}
	
	@RestController
	class ShakyRestController{
		private  ShakyBussinessService shakyBussinessService;
		@Autowired
		public ShakyRestController (ShakyBussinessService shakyBussinessService) {
			this.shakyBussinessService = shakyBussinessService;
			
		}
		@GetMapping("/boom")
		public int boom() throws Exception {
			return this.shakyBussinessService.driveNumber();
		}
		
	}
		
		@Service
		class ShakyBussinessService{
			public int fallback() {				
				return 2;
			}
			@HystrixCommand(fallbackMethod = "fallback")
			public int driveNumber() throws Exception{
				System.out.println("driveNumber called...");
				if(Math.random()>0.5) {
					System.out.println("throwing an exception...");
					Thread.sleep(1000*3);
					throw new RuntimeException();
				}
					return 1;
			}
		}
}
