======================================docker install==================================================
sudo apt-key adv --keyserver hkp://p80.pool.sks-keyservers.net:80 \
      --recv-keys 58118E89F3A912897C070ADBF76221572C52609D
sudo apt-add-repository 'deb https://apt.dockerproject.org/repo ubuntu-xenial main'
sudo apt update
sudo apt install docker-engine
docker
=====================================================================================================
You will need to save the docker image as a tar file:
docker save -o <path for generated tar file> <image name>
Then copy your image to a new system with regular file
 transfer tools such as cp or scp. After that you will have to load the image into docker:
docker load -i <path to image tar file>
eg:
save the docker image as a tar file:
docker save -o /home/hegdepu/dockerfiles/hystrix.tar hystrix-dashboard

copy image to a new system with regular file transfer tools such as cp or scp
load the image into docker
docker load -i /home/hegdepu/dockerfiles/hystrix.tar



======================================docker build commands=====================================

su
docker build -t hystrix-dashboard .
docker images
docker run -p 8085:8085 hystrix-dashboard

docker build -t hystrix-dashboard .
docker build -t microservices-actuator .
docker build -t microservices-circuit-breaker .


docker run -p 7071:7071 --rm hystrix-dashboard
docker run -p 7072:7072 --rm microservices-actuator
docker run -p 7073:7073 --rm microservices-circuit-breaker



docker ps -aq - list all containers
docker ps -s - list all containers with size
docker rm 7cbb36833343 - to remove docker container
docker rmi image_id - to remove docker image


docker system prune - to remove all unused containers
docker system prune -a - remove any stopped containers and all unused images

docker images -f dangling=true - remove dangling images
docker images -aq - list images
docker rmi $(docker images -a -q) - remove all images

docker run --rm image_name - run and remove

===============================docker save files=============================

save the docker image as a tar file:
docker save -o /home/hegdepu/dockerfiles/hystrix.tar hystrix-dashboard

copy image to a new system with regular file transfer tools such as cp or scp
load the image into docker
docker load -i /home/hegdepu/dockerfiles/hystrix.tar
=================================docker swarn commands========================
docker swarm init --advertise-addr <ip-adderss>
docker service ls
docker service ps <name>
docker service create <name> <image-name>
docker service rm <name>
docker service scale <name>=5
docker swarm leave --force

docker node ls
docker node ps
docker node rm <id>
=================================end docker swarn commands========================