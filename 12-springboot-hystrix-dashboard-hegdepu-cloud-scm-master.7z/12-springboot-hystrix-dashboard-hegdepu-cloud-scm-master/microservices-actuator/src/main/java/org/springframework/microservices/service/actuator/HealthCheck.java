package org.springframework.microservices.service.actuator;

import java.util.Random;

import org.springframework.boot.actuate.health.Health;
import org.springframework.boot.actuate.health.HealthIndicator;

public class HealthCheck implements HealthIndicator{

	
	
	private Random random = new Random();
	
	@Override
	public Health health() {
	Health result=null;
	int errorcode = check();
	if(errorcode==0) {
		result = Health.up().build();
	}else {
		result = Health.down().withDetail("error code", errorcode).build();
	}
		return result;
	}
	private int check() {
		int result = 0;
		if(random.nextBoolean()) {
			result = 42;
	}
		return result;
	}

}
