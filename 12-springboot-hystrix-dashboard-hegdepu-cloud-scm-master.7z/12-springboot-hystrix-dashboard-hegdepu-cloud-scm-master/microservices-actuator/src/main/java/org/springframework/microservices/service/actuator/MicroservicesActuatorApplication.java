package org.springframework.microservices.service.actuator;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.hystrix.EnableHystrix;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;

@EnableHystrix
@SpringBootApplication
public class MicroservicesActuatorApplication {

	public static void main(String[] args) {
		SpringApplication.run(MicroservicesActuatorApplication.class, args);
	}
	//http://localhost:7072/actuatorendpoint
	//http://localhost:7072/actuator
	//http://localhost:7072/actuator/hystrix.stream - put in hystix dashboard
	@RestController
	class ActuatorRestController {
		@GetMapping("/actuatorendpoint")
		@HystrixCommand
		public String actuator() throws Exception {
			return "actuator working";
		}

	}
}
